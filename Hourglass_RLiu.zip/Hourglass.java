// Robert Liu 4th period


public class Hourglass {
	
	// prints vertical line used in the ends of the top/bottom of hourglass
	public static void vertLine(String[] args) {
		System.out.print("|");
	}
	
	// prints space to be used throughout hourglass
	public static void Space(String[] args) {
		System.out.print(" ");
	}
	
	// prints colon to used throughout main method of hourglass
	public static void Colon(String[] args) {
		System.out.print(":");
	}
	
	//prints top and bottom of hourglass to be used in main method
	public static void topBottom(String[] args) {
				Hourglass.vertLine(args);
				for(int quote = 1; quote <= 10; quote++) {
					System.out.print("\"");
				}
				Hourglass.vertLine(args);
	}
	
	public static void main(String[]args) {

		Hourglass.topBottom(args);
		System.out.println("");
		//prints top half of hourglass
		
		for(int line = 1; line<=4; line++) {
			for(int space = 0; space<line; space++) {
				Hourglass.Space(args);
			}
			
			System.out.print("\\");
			for(int colon = 1; colon <= -2*line+10; colon++) {
				Hourglass.Colon(args);
			}
			System.out.println("/");
		}
		for(int mid = 1; mid <= 5; mid++) {
			Hourglass.Space(args);
		}
		//midpoint of hourglass
		System.out.println("||");
		
		//bottom half of hourglass 
		for(int line = 1; line<=4; line++) {
			for(int space = 1; space<6-line; space++) {
				Hourglass.Space(args);
			}
				System.out.print("/");
			for(int colon = 1; colon<= 2*line; colon++) {
				Hourglass.Colon(args);
			}
			System.out.println("\\");
		}
		Hourglass.topBottom(args);
	}	
}


